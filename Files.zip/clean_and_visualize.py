"""
Data Cleaning & Visualization Project
--------------------------------------
Loads raw e-commerce sales data, cleans it (missing values, duplicates,
outliers, inconsistent formatting), then builds a visual dashboard of
key findings and writes a short insights report.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid", palette="deep")
plt.rcParams["figure.dpi"] = 110

# ---------------------------------------------------------------
# 1. LOAD
# ---------------------------------------------------------------
raw = pd.read_csv("/home/claude/raw_sales_data.csv", parse_dates=["order_date"])
report_lines = []
report_lines.append("# Data Cleaning & Visualization Report\n")
report_lines.append(f"**Raw dataset:** {raw.shape[0]} rows x {raw.shape[1]} columns\n")

# ---------------------------------------------------------------
# 2. INSPECT
# ---------------------------------------------------------------
missing_before = raw.isna().sum()
dupes_before = raw.duplicated(subset=[c for c in raw.columns if c != "order_id"]).sum()

report_lines.append("## Issues found in raw data\n")
report_lines.append("**Missing values by column:**\n")
for col, n in missing_before[missing_before > 0].items():
    report_lines.append(f"- `{col}`: {n} missing ({n/len(raw):.1%})")
report_lines.append(f"\n**Duplicate rows (excluding order_id):** {dupes_before}\n")

# ---------------------------------------------------------------
# 3. CLEAN
# ---------------------------------------------------------------
df = raw.copy()

# 3a. Standardize text formatting
df["category"] = df["category"].str.strip().str.title()
df["region"] = df["region"].str.strip().str.title()
df["payment_method"] = df["payment_method"].str.strip()

# 3b. Drop exact duplicate orders (keep first occurrence)
before = len(df)
df = df.drop_duplicates(subset=[c for c in df.columns if c != "order_id"], keep="first")
removed_dupes = before - len(df)

# 3c. Fix impossible values (customer_age outliers that are clearly data entry errors)
df.loc[(df["customer_age"] < 15) | (df["customer_age"] > 100), "customer_age"] = np.nan

# 3d. Handle missing values
# - region / payment_method: categorical -> fill with mode
for col in ["region", "payment_method"]:
    df[col] = df[col].fillna(df[col].mode()[0])
# - customer_age, rating: numeric, moderate skew -> fill with median
for col in ["customer_age", "rating"]:
    df[col] = df[col].fillna(df[col].median())
# - unit_price: fill missing using the median price WITHIN that category (more accurate than a global median)
df["unit_price"] = df.groupby("category")["unit_price"].transform(lambda s: s.fillna(s.median()))
# recompute revenue now that unit_price is filled
df["revenue"] = np.round(df["units_sold"] * df["unit_price"], 2)

# 3e. Handle outliers in unit_price using the IQR method (cap, don't drop, to preserve sample size)
Q1, Q3 = df["unit_price"].quantile([0.25, 0.75])
IQR = Q3 - Q1
lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
n_outliers = ((df["unit_price"] < lower) | (df["unit_price"] > upper)).sum()
df["unit_price"] = df["unit_price"].clip(lower=max(lower, 0), upper=upper)
df["revenue"] = np.round(df["units_sold"] * df["unit_price"], 2)

df["order_month"] = df["order_date"].dt.to_period("M").astype(str)

report_lines.append("## Cleaning actions taken\n")
report_lines.append(f"- Standardized text casing in `category`, `region`, `payment_method`")
report_lines.append(f"- Removed {removed_dupes} duplicate orders")
report_lines.append(f"- Nulled out {((raw['customer_age']<15)|(raw['customer_age']>100)).sum()} impossible ages (e.g. 150, -5) before imputing")
report_lines.append(f"- Filled missing categorical values (`region`, `payment_method`) with the mode")
report_lines.append(f"- Filled missing `customer_age`/`rating` with the median")
report_lines.append(f"- Filled missing `unit_price` with the **category-level** median (more accurate than a global fill)")
report_lines.append(f"- Capped {n_outliers} `unit_price` outliers to the IQR bounds (₹{lower:.0f} - ₹{upper:.0f}) instead of dropping rows")
report_lines.append(f"\n**Clean dataset:** {df.shape[0]} rows x {df.shape[1]} columns, 0 missing values remaining: {df.isna().sum().sum() == 0}\n")

df.to_csv("/home/claude/clean_sales_data.csv", index=False)

# ---------------------------------------------------------------
# 4. VISUALIZE -- dashboard of 6 panels
# ---------------------------------------------------------------
fig, axes = plt.subplots(2, 3, figsize=(19, 11))
fig.suptitle("Sales Data Dashboard — 2024", fontsize=18, fontweight="bold")

# Panel 1: Missing values before cleaning
ax = axes[0, 0]
missing_before[missing_before > 0].sort_values().plot(kind="barh", ax=ax, color="#d95f5f")
ax.set_title("Missing Values (Raw Data)")
ax.set_xlabel("Count")

# Panel 2: Revenue by category
ax = axes[0, 1]
cat_rev = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
sns.barplot(x=cat_rev.values, y=cat_rev.index, ax=ax, hue=cat_rev.index, legend=False, palette="viridis")
ax.set_title("Total Revenue by Category")
ax.set_xlabel("Revenue (₹)")
ax.set_ylabel("")

# Panel 3: Monthly revenue trend
ax = axes[0, 2]
monthly = df.groupby("order_month")["revenue"].sum()
ax.plot(monthly.index, monthly.values, marker="o", color="#2b6cb0")
ax.set_title("Monthly Revenue Trend")
ax.set_xticks(range(0, len(monthly), 2))
ax.set_xticklabels(monthly.index[::2], rotation=45, ha="right")
ax.set_ylabel("Revenue (₹)")

# Panel 4: Unit price distribution before vs after outlier handling
ax = axes[1, 0]
sns.histplot(raw["unit_price"].dropna(), bins=40, color="#d95f5f", alpha=0.5, label="Raw (with outliers)", ax=ax)
sns.histplot(df["unit_price"], bins=40, color="#2f855a", alpha=0.6, label="Cleaned (capped)", ax=ax)
ax.set_title("Unit Price Distribution: Before vs After")
ax.set_xlabel("Unit Price (₹)")
ax.legend()

# Panel 5: Revenue by region and payment method (heatmap)
ax = axes[1, 1]
pivot = df.pivot_table(index="region", columns="payment_method", values="revenue", aggfunc="sum")
sns.heatmap(pivot, annot=True, fmt=".0f", cmap="YlGnBu", ax=ax, cbar_kws={"label": "Revenue (₹)"})
ax.set_title("Revenue: Region x Payment Method")

# Panel 6: Rating distribution by category
ax = axes[1, 2]
sns.boxplot(data=df, x="category", y="rating", ax=ax, hue="category", legend=False, palette="Set2")
ax.set_title("Customer Rating Spread by Category")
ax.set_xticklabels(ax.get_xticklabels(), rotation=30, ha="right")
ax.set_xlabel("")

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("/home/claude/dashboard.png", bbox_inches="tight")
print("Dashboard saved.")

# ---------------------------------------------------------------
# 5. KEY FINDINGS
# ---------------------------------------------------------------
top_cat = cat_rev.idxmax()
top_region_pay = pivot.stack().idxmax()
best_month = monthly.idxmax()

report_lines.append("## Key findings\n")
report_lines.append(f"- **{top_cat}** generated the most total revenue (₹{cat_rev.max():,.0f})")
report_lines.append(f"- **{best_month}** was the strongest month (₹{monthly.max():,.0f} in revenue)")
report_lines.append(f"- The highest-revenue combination was **{top_region_pay[0]} region paying via {top_region_pay[1]}** (₹{pivot.stack().max():,.0f})")
report_lines.append(f"- Average customer rating across all categories: {df['rating'].mean():.2f}/5")
report_lines.append(f"- After cleaning, average order revenue is ₹{df['revenue'].mean():,.0f} (was ₹{raw['revenue'].mean():,.0f} in the raw, outlier-skewed data)")

with open("/home/claude/insights_report.md", "w") as f:
    f.write("\n".join(report_lines))

print("\n".join(report_lines))
