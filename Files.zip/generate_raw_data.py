"""
Generates a synthetic, deliberately messy e-commerce sales dataset.
Includes missing values, duplicate rows, outliers, and inconsistent
formatting -- the kind of raw data you'd actually be handed.
"""
import numpy as np
import pandas as pd

np.random.seed(42)

N = 1200

categories = ["Electronics", "Clothing", "Home & Kitchen", "Books", "Sports", "Beauty"]
regions = ["North", "South", "East", "West"]
payment_methods = ["Credit Card", "Debit Card", "UPI", "Net Banking", "Cash on Delivery"]

dates = pd.date_range("2024-01-01", "2024-12-31", freq="D")

df = pd.DataFrame({
    "order_id": np.arange(10000, 10000 + N),
    "order_date": np.random.choice(dates, N),
    "category": np.random.choice(categories, N, p=[0.22, 0.2, 0.18, 0.12, 0.14, 0.14]),
    "region": np.random.choice(regions, N),
    "payment_method": np.random.choice(payment_methods, N),
    "units_sold": np.random.randint(1, 8, N),
    "unit_price": np.round(np.random.gamma(shape=3.0, scale=350, size=N), 2),
    "customer_age": np.random.randint(18, 70, N),
    "rating": np.round(np.random.uniform(1, 5, N), 1),
})

df["revenue"] = np.round(df["units_sold"] * df["unit_price"], 2)

# --- Inject messiness ---

# 1. Missing values across several columns
for col, frac in [("unit_price", 0.05), ("customer_age", 0.08), ("rating", 0.10), ("region", 0.03), ("payment_method", 0.04)]:
    idx = np.random.choice(df.index, size=int(len(df) * frac), replace=False)
    df.loc[idx, col] = np.nan

# 2. Outliers - a handful of absurd unit prices and ages
outlier_idx = np.random.choice(df.index, size=15, replace=False)
df.loc[outlier_idx, "unit_price"] = df.loc[outlier_idx, "unit_price"] * np.random.uniform(15, 40, 15)

age_outlier_idx = np.random.choice(df.index, size=8, replace=False)
df.loc[age_outlier_idx, "customer_age"] = np.random.choice([120, 150, -5, 200], 8)

# recompute revenue after outlier injection (with some NaNs propagating naturally)
df["revenue"] = np.round(df["units_sold"] * df["unit_price"], 2)

# 3. Duplicate rows (exact duplicates of random existing orders)
dupes = df.sample(40, random_state=1).copy()
df = pd.concat([df, dupes], ignore_index=True)

# 4. Inconsistent text formatting
df["category"] = df["category"].astype(object)
messy_case_idx = np.random.choice(df.index, size=60, replace=False)
df.loc[messy_case_idx, "category"] = df.loc[messy_case_idx, "category"].str.upper()

df["region"] = df["region"].astype(object)
messy_region_idx = np.random.choice(df.dropna(subset=["region"]).index, size=40, replace=False)
df.loc[messy_region_idx, "region"] = df.loc[messy_region_idx, "region"].str.lower()

# 5. Shuffle rows so it doesn't look pre-sorted
df = df.sample(frac=1, random_state=7).reset_index(drop=True)

df.to_csv("/home/claude/raw_sales_data.csv", index=False)
print("Raw dataset created:", df.shape)
print(df.isna().sum())
